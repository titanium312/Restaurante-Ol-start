import React, { useState } from 'react';
import styles from './ProductosManejo.module.css';
import BuscadorProducto from './BuscadorProducto/BuscadorProducto';

function ProductosManejo({ provedores = [], metodosPago = [] }) {
  const [modoOperacion, setModoOperacion] = useState('compra');

  const [searchTerm, setSearchTerm] = useState('');
  const [productoSeleccionado, setProductoSeleccionado] = useState(null);

  const [idProducto, setIdProducto] = useState('');
  const [nombreProducto, setNombreProducto] = useState('');
  const [cantidad, setCantidad] = useState('');
  const [precioCompra, setPrecioCompra] = useState('');
  const [proveedorId, setProveedorId] = useState('');
  const [metodoPago, setMetodoPago] = useState('1');
  const [descuento, setDescuento] = useState('0');
  const [adelanto, setAdelanto] = useState('0');

  const [items, setItems] = useState([]);
  const [message, setMessage] = useState('');

  const agregarItem = () => {
    if (!idProducto || !cantidad || cantidad <= 0 || !precioCompra || precioCompra <= 0) {
      return alert('Completa los campos ID Producto, Cantidad y Precio válido');
    }

    const existe = items.find(item => item.idProducto === Number(idProducto));
    if (existe) {
      return alert('Este producto ya fue agregado');
    }

    setItems([
      ...items,
      {
        idProducto: Number(idProducto),
        cantidad: Number(cantidad),
        precioCompra: parseFloat(precioCompra),
      },
    ]);

    // Limpiar campos
    setIdProducto('');
    setNombreProducto('');
    setSearchTerm('');
    setProductoSeleccionado(null);
    setCantidad('');
    setPrecioCompra('');
  };

  const quitarItem = idx => {
    setItems(items.filter((_, i) => i !== idx));
  };

  const calcularTotal = () => {
    return items.reduce((acc, item) => acc + item.cantidad * item.precioCompra, 0).toFixed(2);
  };

  const handleSubmit = async () => {
    if (!proveedorId || proveedorId <= 0) return alert('Ingresa un ID de proveedor válido');
    if (items.length === 0) return alert('Agrega al menos un producto');

    const payload = {
      productos: items.map(({ idProducto, cantidad, precioCompra }) => ({
        idProducto,
        cantidad,
        precioCompra,
      })),
      proveedorId: Number(proveedorId),
      tipoFactura: modoOperacion === 'compra' ? 1 : 2,
      metodoPago: Number(metodoPago),
      descuento: parseFloat(descuento),
      adelanto: parseFloat(adelanto),
    };

    try {
      const res = await fetch('http://localhost:1234/Hotel/Productos/productos/entrada', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });

      if (!res.ok) {
        const errorData = await res.json();
        console.error('Error backend:', errorData);
        throw new Error(errorData.error || 'Error en la petición');
      }

      setItems([]);
      setProveedorId('');
      setDescuento('0');
      setAdelanto('0');
      setMetodoPago('1');
      setMessage(modoOperacion === 'compra' ? 'Compra registrada con éxito' : 'Venta registrada con éxito');
      alert(modoOperacion === 'compra' ? 'Compra registrada con éxito' : 'Venta registrada con éxito');
    } catch (error) {
      alert('Error al registrar la operación');
      console.error(error);
    }
  };

  return (
    <div className={styles.formularioContenedor}>
      <h1 className={styles.tituloFormulario}>
        Gestión de Productos - {modoOperacion === 'compra' ? 'Compra' : 'Venta'}
      </h1>

      <div className={styles.grillaCampos}>
        <label>
          <input
            type="radio"
            name="modo"
            value="compra"
            checked={modoOperacion === 'compra'}
            onChange={() => setModoOperacion('compra')}
          />
          Compra
        </label>
        <label>
          <input
            type="radio"
            name="modo"
            value="venta"
            checked={modoOperacion === 'venta'}
            onChange={() => setModoOperacion('venta')}
          />
          Venta
        </label>
      </div>

      <div className={styles.grillaCampos}>
        <BuscadorProducto
          searchTerm={searchTerm}
          setSearchTerm={setSearchTerm}
          onSelect={(producto) => {
            setProductoSeleccionado(producto);
            setIdProducto(producto.ID.toString());
            setNombreProducto(producto.Nombre);
            setSearchTerm(producto.ID.toString());
          }}
        />

        {productoSeleccionado && (
          <p>Producto seleccionado: <strong>{productoSeleccionado.Nombre}</strong></p>
        )}

        <input
          type="text"
          placeholder="ID Producto"
          value={idProducto}
          readOnly
        />

        <input
          type="number"
          placeholder="Cantidad"
          min="1"
          value={cantidad}
          onChange={e => setCantidad(e.target.value)}
        />
        <input
          type="number"
          placeholder="Precio Compra"
          min="0"
          step="0.01"
          value={precioCompra}
          onChange={e => setPrecioCompra(e.target.value)}
        />
        <button className={styles.buttonP} onClick={agregarItem}>Agregar Producto</button>
      </div>

      {items.length > 0 && (
        <table className={styles.tablaProductos}>
          <thead>
            <tr>
              <th>ID Producto</th>
              <th>Cantidad</th>
              <th>Precio Compra</th>
              <th>Quitar</th>
            </tr>
          </thead>
          <tbody>
            {items.map((item, idx) => (
              <tr key={idx}>
                <td>{item.idProducto}</td>
                <td>{item.cantidad}</td>
                <td>{item.precioCompra.toFixed(2)}</td>
                <td>
                  <button
                    className={styles.botonQuitarItem}
                    onClick={() => quitarItem(idx)}
                  >
                    Quitar
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      )}

      <div className={styles.grillaCampos}>
        <select value={proveedorId} onChange={(e) => setProveedorId(e.target.value)}>
          <option value="">-- Selecciona un proveedor --</option>
          {provedores.map((p) => (
            <option key={p.ID_Provedor} value={p.ID_Provedor.toString()}>
              {p.Nombre}
            </option>
          ))}
        </select>

        <label>
          Método de Pago:
          <select
            value={metodoPago}
            onChange={e => setMetodoPago(e.target.value)}
            required
          >
            <option value="">-- Seleccione --</option>
            {metodosPago.map((m) => (
              <option key={m.ID_MetodoPago} value={m.ID_MetodoPago.toString()}>
                {m.Descripcion}
              </option>
            ))}
          </select>
        </label>

        <input
          type="number"
          placeholder="Descuento"
          min="0"
          step="0.01"
          value={descuento}
          onChange={e => setDescuento(e.target.value)}
        />
        <input
          type="number"
          placeholder="Adelanto"
          min="0"
          step="0.01"
          value={adelanto}
          onChange={e => setAdelanto(e.target.value)}
        />
      </div>

      {items.length > 0 && (
        <p className={styles.totalInfo}>Total: ${calcularTotal()}</p>
      )}

      <button className={styles.buttonP} onClick={handleSubmit}>
        {modoOperacion === 'compra' ? 'Registrar Compra' : 'Registrar Venta'}
      </button>

      {message && <p className={styles.mensajeAlerta}>{message}</p>}
    </div>
  );
}

export default ProductosManejo;
