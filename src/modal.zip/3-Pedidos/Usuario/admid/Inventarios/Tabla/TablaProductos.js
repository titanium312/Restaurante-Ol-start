import React, { useEffect, useState } from "react";

export default function TablaProductos({ recargarTabla, onEditar }) {
  const [productos, setProductos] = useState([]);
  const [cargando, setCargando] = useState(true);
  const [error, setError] = useState(null);

  const cargarProductos = () => {
    setCargando(true);
    fetch("http://localhost:1234/Hotel/productos/productos-Optener")
      .then((res) => res.json())
      .then((data) => {
        setProductos(data || []);
        setCargando(false);
      })
      .catch((err) => {
        setError("Error al cargar productos");
        console.error(err);
        setCargando(false);
      });
  };

  useEffect(() => {
    cargarProductos();
  }, [recargarTabla]);

  if (cargando) return <p>Cargando productos...</p>;
  if (error) return <p style={{ color: "red" }}>{error}</p>;

  return (
    <div style={{ marginTop: 30 }}>
      <h2>Lista de Productos</h2>
      {productos.length === 0 ? (
        <p>No hay productos registrados.</p>
      ) : (
        <table border="1" cellPadding="8" cellSpacing="0" style={{ width: "100%" }}>
          <thead>
            <tr>
              <th>ID</th>
              <th>Nombre</th>
              <th>Descripción</th>
              <th>Precio Unitario</th>
              <th>Stock</th>
              <th>Proveedor</th>
              <th>Tipo</th>
              <th>Unidad</th>
              <th>Acciones</th>
            </tr>
          </thead>
          <tbody>
            {productos.map((p) => (
              <tr key={p.ID}>
                <td>{p.ID}</td>
                <td>{p.Nombre}</td>
                <td>{p.Descripcion}</td>
                <td>{p.Precio_Unitario}</td>
                <td>{p.Stock}</td>
                <td>{p.Proveedor || "—"}</td>
                <td>{p.Tipo || "—"}</td>
                <td>{p.Unidad || "—"}</td>
                <td>
                  <button
                    onClick={() =>
                      onEditar({
                        ID_Producto: p.ID,
                        nombre: p.Nombre,
                        descripcion: p.Descripcion,
                        Precio_Unitario: p.Precio_Unitario,
                        Stock: p.Stock,
                        Proveedor: p.Proveedor,
                        Tipo: p.Tipo,
                        Unidad: p.Unidad,
                      })
                    }
                  >
                    Editar
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
}
