import React, { useEffect, useState } from "react";


export function FormularioProducto({ productoEditar, onSuccess, onCancelar, tiposProducto, unidades, provedores }) {
  const isEditing = !!productoEditar;

  const [formData, setFormData] = useState({
    ID_Producto: "",
    nombre: "",
    descripcion: "",
    Precio_Unitario: "",
    Stock: "",
    ID_Provedor: "",
    ID_producto_tipo: "",
    ID_Unidad: "",
  });

  const [mensaje, setMensaje] = useState("");

  // Cargar datos del producto cuando esté en modo edición y las listas estén listas
  useEffect(() => {
    if (
      isEditing &&
      productoEditar &&
      tiposProducto.length > 0 &&
      unidades.length > 0 &&
      provedores.length > 0
    ) {
      const proveedorEncontrado = provedores.find(
        (p) => p.Nombre === productoEditar.Proveedor
      );
      const tipoEncontrado = tiposProducto.find(
        (t) => t.Descripcion === productoEditar.Tipo
      );
      const unidadEncontrada = unidades.find(
        (u) => u.Descripcion === productoEditar.Unidad
      );

      setFormData({
        ID_Producto: productoEditar.ID_Producto?.toString() || "",
        nombre: productoEditar.nombre || "",
        descripcion: productoEditar.descripcion || "",
        Precio_Unitario: productoEditar.Precio_Unitario?.toString() || "",
        Stock: productoEditar.Stock?.toString() || "",
        ID_Provedor: proveedorEncontrado?.ID_Provedor?.toString() || "",
        ID_producto_tipo: tipoEncontrado?.ID_producto_tipo?.toString() || "",
        ID_Unidad: unidadEncontrada?.ID_Unidad?.toString() || "",
      });
    }
  }, [productoEditar, isEditing, tiposProducto, unidades, provedores]);

  const handleChange = (e) => {
    const { id, value } = e.target;
    setFormData((prev) => ({ ...prev, [id]: value }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();

    if (!formData.nombre.trim()) return alert("El nombre es obligatorio");
    if (!formData.ID_producto_tipo) return alert("Selecciona tipo");
    if (!formData.ID_Unidad) return alert("Selecciona unidad");
    if (isNaN(formData.Precio_Unitario) || formData.Precio_Unitario === "")
      return alert("Precio inválido");
    if (isNaN(formData.Stock) || formData.Stock === "") return alert("Stock inválido");

    const payload = {
      ...(formData.ID_Producto && { ID_Producto: parseInt(formData.ID_Producto) }),
      nombre: formData.nombre.trim(),
      descripcion: formData.descripcion.trim(),
      Precio_Unitario: parseFloat(formData.Precio_Unitario),
      Stock: parseInt(formData.Stock),
      ID_Provedor: formData.ID_Provedor ? parseInt(formData.ID_Provedor) : null,
      ID_producto_tipo: parseInt(formData.ID_producto_tipo),
      ID_Unidad: parseInt(formData.ID_Unidad),
    };

    const url = `http://localhost:1234/Hotel/Productos/CrearProductos`;

    fetch(url, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    })
      .then((res) => {
        if (!res.ok) throw new Error("Servidor no respondió bien");
        return res.json();
      })
      .then((d) => {
        setMensaje(d.message || "Operación exitosa");
        if (!isEditing) {
          setFormData({
            ID_Producto: "",
            nombre: "",
            descripcion: "",
            Precio_Unitario: "",
            Stock: "",
            ID_Provedor: "",
            ID_producto_tipo: "",
            ID_Unidad: "",
          });
        }
        if (onSuccess) onSuccess();
      })
      .catch((e) => setMensaje("Error de conexión: " + e.message));
  };

  return (
    <form onSubmit={handleSubmit} style={{ maxWidth: 600, margin: "auto" }}>
      <h2>{isEditing ? "Editar Producto" : "Crear Producto"}</h2>

      {!isEditing ? (
        <label>
          ID (opcional):
          <input
            type="number"
            id="ID_Producto"
            value={formData.ID_Producto}
            onChange={handleChange}
            placeholder="Dejar vacío para autogenerar"
            min="1"
          />
        </label>
      ) : (
        <label>
          ID:
          <input type="number" id="ID_Producto" value={formData.ID_Producto} disabled />
        </label>
      )}

      <label>
        Nombre:
        <input
          type="text"
          id="nombre"
          value={formData.nombre}
          onChange={handleChange}
          required
        />
      </label>

      <label>
        Descripción:
        <textarea id="descripcion" value={formData.descripcion} onChange={handleChange} />
      </label>

      <label>
        Precio Unitario:
        <input
          type="number"
          id="Precio_Unitario"
          value={formData.Precio_Unitario}
          onChange={handleChange}
          step="0.01"
          required
        />
      </label>

      <label>
        Stock:
        <input type="number" id="Stock" value={formData.Stock} onChange={handleChange} required />
      </label>

      <label>
        Proveedor:
<label>
  Proveedor:
  <select id="ID_Provedor" value={formData.ID_Provedor} onChange={handleChange}>
    <option value="">-- Ninguno --</option>
    {provedores.map((p) => (
      <option key={p.ID_Provedor} value={p.ID_Provedor.toString()}>
        {p.Nombre}
      </option>
    ))}
  </select>
</label>
      </label>

      <label>
        Tipo:
        <select id="ID_producto_tipo" value={formData.ID_producto_tipo} onChange={handleChange} required>
          <option value="">-- Seleccione --</option>
          {tiposProducto.map((t) => (
            <option key={t.ID_producto_tipo} value={t.ID_producto_tipo.toString()}>
              {t.Descripcion}
            </option>
          ))}
        </select>
      </label>

      <label>
        Unidad:
        <select id="ID_Unidad" value={formData.ID_Unidad} onChange={handleChange} required>
          <option value="">-- Seleccione --</option>
          {unidades.map((u) => (
            <option key={u.ID_Unidad} value={u.ID_Unidad.toString()}>
              {u.Descripcion}
            </option>
          ))}
        </select>
      </label>

      <button type="submit" style={{ marginTop: 10 }}>
        {isEditing ? "Actualizar" : "Crear"} Producto
      </button>

      {mensaje && (
        <p style={{ color: mensaje.includes("Error") ? "red" : "green", marginTop: 10 }}>
          {mensaje}
        </p>
      )}

      {isEditing && (
        <button
          type="button"
          onClick={onCancelar}
          style={{ marginLeft: 10, marginTop: 10 }}
        >
          Cancelar
        </button>
      )}
    </form>
  );
}
