import React, { useState, useEffect } from "react";
import TablaProductos from "./Tabla/TablaProductos";
import { FormularioProducto } from "./Formulario/FormularioProducto";
import ProductosManejo from "./Entrada/ProductosManejo";

export default function ContenedorProductos() {
  const [productoEditar, setProductoEditar] = useState(null);
  const [recargarTabla, setRecargarTabla] = useState(false);

  const [tiposProducto, setTiposProducto] = useState([]);
  const [unidades, setUnidades] = useState([]);
  const [provedores, setProvedores] = useState([]);
  const [metodosPago, setMetodosPago] = useState([]);

  // Estado para controlar qué vista se muestra: "formulario" o "manejo"
  const [vistaActiva, setVistaActiva] = useState("formulario");

  useEffect(() => {
    fetch("http://localhost:1234/Hotel/Productos/producto-tipos")
      .then((res) => res.json())
      .then((d) => setTiposProducto(d.data || d))
      .catch(() => setTiposProducto([]));

    fetch("http://localhost:1234/Hotel/Productos/unidades")
      .then((res) => res.json())
      .then((d) => setUnidades(d.data || d))
      .catch(() => setUnidades([]));

    fetch("http://localhost:1234/Hotel/Productos/provedores")
      .then((res) => res.json())
      .then((d) => setProvedores(d.data || d))
      .catch(() => setProvedores([]));

    fetch("http://localhost:1234/Hotel/Recepcion/metodos-pago")
      .then((res) => res.json())
      .then((d) => setMetodosPago(d.data || d))
      .catch(() => setMetodosPago([]));
  }, []);

  const manejarEditar = (producto) => {
    setProductoEditar(producto);
    setVistaActiva("formulario");
  };

  const manejarExito = () => {
    setRecargarTabla((prev) => !prev);
    setProductoEditar(null);
  };

  const manejarCancelar = () => {
    setProductoEditar(null);
  };

  return (
    <div style={{ padding: 20 }}>
      <h1>Gestión de Productos</h1>

      {/* Botones de selección de vista */}
      <div style={{ display: "flex", gap: "10px", marginBottom: "20px" }}>
        <button
          onClick={() => setVistaActiva("formulario")}
          style={{
            padding: "10px",
            backgroundColor: vistaActiva === "formulario" ? "#4caf50" : "#ccc",
            color: "white",
            border: "none",
            borderRadius: "4px",
          }}
        >
          Ingresar o Actualizar
        </button>

        <button
          onClick={() => setVistaActiva("manejo")}
          style={{
            padding: "10px",
            backgroundColor: vistaActiva === "manejo" ? "#2196f3" : "#ccc",
            color: "white",
            border: "none",
            borderRadius: "4px",
          }}
        >
          Entrada o Salida
        </button>
      </div>

      {/* Renderizado condicional */}
      <div>
        {vistaActiva === "formulario" && (
          <FormularioProducto
            productoEditar={productoEditar}
            onSuccess={manejarExito}
            onCancelar={manejarCancelar}
            tiposProducto={tiposProducto}
            unidades={unidades}
            provedores={provedores}
          />
        )}

        {vistaActiva === "manejo" && (
          <ProductosManejo
            provedores={provedores}
            metodosPago={metodosPago}
          />
        )}
      </div>

      <TablaProductos recargarTabla={recargarTabla} onEditar={manejarEditar} />

      <hr style={{ margin: "20px 0" }} />
    </div>
  );
}
