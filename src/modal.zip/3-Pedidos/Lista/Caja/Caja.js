import React, { useState, useEffect, useCallback } from 'react';
import api from '../../../api';
import styles from './CajaManagement.module.css';

function CajaManagement() {
  const today = new Date().toISOString().slice(0, 10);

  const [selectedDate, setSelectedDate] = useState(today);
  const [comentario, setComentario] = useState('');
  const [actionMessage, setActionMessage] = useState('');
  const [actionError, setActionError] = useState('');
  const [cajaData, setCajaData] = useState(null);
  const [cajaLoading, setCajaLoading] = useState(false);
  const [cajaError, setCajaError] = useState(null);
  const [totalesMetodosPago, setTotalesMetodosPago] = useState({});

  const username = localStorage.getItem('username');
  const role = localStorage.getItem('role');

  const esFechaHoy = selectedDate === today;

  // Función para cargar estado caja según fecha seleccionada
  const fetchCajaEstado = useCallback(async () => {
    setCajaLoading(true);
    setCajaError(null);
    try {
      const result = await api.obtenerDatos(`/hotel/restaurante/CajaEstado?fecha=${selectedDate}`, null, 'POST');
      setCajaData(Array.isArray(result) && result.length > 0 ? result[0] : null);
    } catch (err) {
      setCajaError(err.message || 'Error al obtener estado de caja');
      setCajaData(null);
    } finally {
      setCajaLoading(false);
    }
  }, [selectedDate]);

  // Totales por método de pago para la fecha seleccionada
  const fetchTotalesPorMetodoPago = useCallback(async () => {
    try {
      const data = await api.obtenerDatos(`/Hotel/restaurante/servicio/Recepcion-ServiciosList?fechaInicio=${selectedDate}&fechaFin=${selectedDate}`);
      if (data.Bar && Array.isArray(data.Bar)) {
        return data.Bar.reduce((acc, servicio) => {
          const metodo = servicio.Metodo_Pago || 'Sin Método';
          const total = parseFloat(servicio.Total) || 0;
          acc[metodo] = (acc[metodo] || 0) + total;
          return acc;
        }, {});
      }
      return {};
    } catch (error) {
      console.error('Error al obtener totales por método de pago:', error);
      return {};
    }
  }, [selectedDate]);

  const loadTotalesIfCajaCerrada = useCallback(async () => {
    if (cajaData?.Descripcion === 'Cerrada') {
      const totales = await fetchTotalesPorMetodoPago();
      setTotalesMetodosPago(totales);
    } else {
      setTotalesMetodosPago({});
    }
  }, [cajaData, fetchTotalesPorMetodoPago]);

  useEffect(() => {
    fetchCajaEstado();
  }, [fetchCajaEstado]);

  useEffect(() => {
    loadTotalesIfCajaCerrada();
  }, [cajaData, loadTotalesIfCajaCerrada]);

  const handleCajaAction = async (actionType) => {
    setActionMessage('');
    setActionError('');
    setTotalesMetodosPago({});

    // Validar rol y fecha para acción
    if (role === 'Administrador') {
      // Admin puede cualquier fecha
    } else if (role === 'Editor') {
      if (!esFechaHoy) {
        setActionError('Los editores solo pueden abrir o cerrar la caja para la fecha de hoy.');
        return;
      }
    } else {
      setActionError('Solo administradores o editores pueden realizar esta acción.');
      return;
    }

    if (actionType === 'abrir') {
      if (cajaData?.Descripcion === 'Abierta') {
        setActionError('La caja ya está abierta.');
        return;
      }
    }

    if (actionType === 'cerrar' && cajaData?.Descripcion !== 'Abierta') {
      setActionError('No se puede cerrar la caja porque no está abierta.');
      return;
    }

    if (!comentario.trim()) {
      setActionError('Por favor, ingresa un comentario.');
      return;
    }

    if (!username) {
      setActionError('No se encontró usuario logueado. Por favor inicia sesión.');
      return;
    }

    let totales = {};
    if (actionType === 'cerrar') {
      totales = await fetchTotalesPorMetodoPago();
      setTotalesMetodosPago(totales);
    }

    const payload = {
      descripcion: actionType === 'abrir' ? 'Abierta' : 'Cerrada',
      comentario: `${username}: ${comentario}`,
      usuario: username,
      fecha: selectedDate,
    };

    try {
      await api.obtenerDatos('/hotel/restaurante/Caja', payload, 'POST');
      setActionMessage(`Caja ${actionType === 'abrir' ? 'abierta' : 'cerrada'} exitosamente.`);
      setComentario('');
      fetchCajaEstado();
    } catch (err) {
      setActionError(err.message || 'Error al realizar la acción en caja.');
    }
  };

  const cajaAbierta = cajaData?.Descripcion === 'Abierta';

  // Botones habilitados
  const botonAbrirHabilitado =
    (role === 'Administrador' || (role === 'Editor' && esFechaHoy)) && !cajaAbierta;

  const botonCerrarHabilitado =
    (role === 'Administrador' || (role === 'Editor' && esFechaHoy)) && cajaAbierta;

  const inputComentarioHabilitado = role === 'Administrador' || (role === 'Editor' && esFechaHoy);

  return (
    <div className={styles['caja-container-x7f9r2']}>
      <div className={styles['caja-content-x7f9r2']}>
        <h2 className={styles['caja-header-x7f9r2']}>💰 Gestión de Caja del Restaurante</h2>

        <section className={styles['caja-section-x7f9r2']}>
          <label htmlFor="fecha" style={{ marginRight: '8px' }}>📅 Selecciona Fecha:</label>
          <input
            type="date"
            id="fecha"
            value={selectedDate}
            max={today}
            onChange={(e) => setSelectedDate(e.target.value)}
          />
        </section>

        <section className={styles['caja-section-x7f9r2']}>
          <h3 className={styles['caja-section-title-x7f9r2']}>
            📊 Estado Actual de Caja ({selectedDate})
            {cajaData && (
              <span
                className={`${styles['caja-status-badge-x7f9r2']} ${
                  cajaAbierta ? styles['caja-status-open-x7f9r2'] : styles['caja-status-closed-x7f9r2']
                }`}
                style={{ marginLeft: '8px' }}
              >
                {cajaData.Descripcion}
              </span>
            )}
          </h3>

          {cajaLoading && (
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
              <div className={styles['caja-loading-spinner-x7f9r2']}></div>
              <p>Cargando estado...</p>
            </div>
          )}

          {cajaError && <p className={styles['caja-msg-error-x7f9r2']}>⚠️ Error: {cajaError}</p>}

          {cajaData ? (
            <>
              <div className={styles['caja-info-x7f9r2']}>
                <strong>📋 Descripción:</strong> {cajaData.Descripcion}
              </div>
              <div className={styles['caja-info-x7f9r2']}>
                <strong>🗓️ Fecha:</strong> {new Date(cajaData.Fecha).toLocaleDateString()}
              </div>
              <div className={styles['caja-info-x7f9r2']}>
                <strong>📝 Comentarios:</strong>
                <pre className={styles['caja-comments-x7f9r2']}>{cajaData.Comentario}</pre>
              </div>
            </>
          ) : (
            !cajaLoading && <p>No hay estado registrado para esta fecha.</p>
          )}

          {cajaData?.Descripcion === 'Cerrada' && (
            <>
              <h4>💳 Totales por método de pago</h4>
              {Object.keys(totalesMetodosPago).length > 0 ? (
                <ul className={styles['caja-metodos-list-x7f9r2']}>
                  {Object.entries(totalesMetodosPago).map(([metodo, total]) => (
                    <li key={metodo}>
                      {metodo}: <strong>${total.toFixed(2)}</strong>
                    </li>
                  ))}
                </ul>
              ) : (
                <p>No hay datos de pagos para esta fecha.</p>
              )}
            </>
          )}
        </section>

        <section className={styles['caja-section-x7f9r2']}>
          <textarea
            className={styles['caja-input-comentario-x7f9r2']}
            rows={5}
            placeholder="Escribe un comentario para la acción (obligatorio)"
            value={comentario}
            onChange={e => setComentario(e.target.value)}
            disabled={!inputComentarioHabilitado}
          />
        </section>

        <section className={styles['caja-section-x7f9r2']}>
          <button
            className={styles['caja-button-x7f9r2']}
            disabled={!botonAbrirHabilitado}
            onClick={() => handleCajaAction('abrir')}
            style={{ marginRight: '10px' }}
          >
            Abrir Caja
          </button>

          <button
            className={styles['caja-button-x7f9r2']}
            disabled={!botonCerrarHabilitado}
            onClick={() => handleCajaAction('cerrar')}
          >
            Cerrar Caja
          </button>
        </section>

        {actionMessage && <p className={styles['caja-msg-success-x7f9r2']}>✅ {actionMessage}</p>}
        {actionError && <p className={styles['caja-msg-error-x7f9r2']}>⚠️ {actionError}</p>}
      </div>
    </div>
  );
}

export default CajaManagement;
